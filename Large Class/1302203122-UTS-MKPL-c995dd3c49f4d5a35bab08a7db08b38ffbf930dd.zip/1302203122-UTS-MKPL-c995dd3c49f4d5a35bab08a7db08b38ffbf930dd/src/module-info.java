module TaxCalculator {
	
	
	
	
}